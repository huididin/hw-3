//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package model;

public class RowBlockModel {
    private RowGameModel game;
    private String contents;
    private boolean isLegalMove;
    private boolean editable;

    public RowBlockModel(RowGameModel game) {
        if (game == null) {
            throw new IllegalArgumentException("The game must be non-null.");
        } else {
            this.game = game;
            this.reset();
        }
    }

    public RowGameModel getGame() {
        return this.game;
    }

    public void setContents(String value) {
        if (value == null) {
            throw new IllegalArgumentException("The value must be non-null.");
        } else {
            this.contents = value;
        }
    }

    public String getContents() {
        return this.contents;
    }

    public void setIsLegalMove(boolean isLegalMove) {
        this.isLegalMove = isLegalMove;
    }

    public boolean getIsLegalMove() {
        return this.isLegalMove;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public boolean getIsEditable() {
        return this.editable;
    }

    public void reset() {
        this.contents = "";
        this.isLegalMove = false;
    }
}

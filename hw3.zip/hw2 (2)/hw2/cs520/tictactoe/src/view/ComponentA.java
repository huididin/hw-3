//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package view;

import controller.RowGameController;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import model.RowGameModel;

public class ComponentA implements View {
    public JButton[][] blocks = new JButton[3][3];

    public ComponentA(final RowGameController controller, JPanel game) {
        for(int row = 0; row < 3; ++row) {
            for(int column = 0; column < 3; ++column) {
                this.blocks[row][column] = new JButton();
                this.blocks[row][column].setPreferredSize(new Dimension(75, 75));
                game.add(this.blocks[row][column]);
                this.blocks[row][column].addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        controller.move((JButton)e.getSource());
                    }
                });
            }
        }

    }

    public void updateBlock(RowGameModel gameModel, int row, int column) {
        this.blocks[row][column].setText(gameModel.blocksData[row][column].getContents());
        this.blocks[row][column].setEnabled(gameModel.blocksData[row][column].getIsLegalMove());
    }

    public void update(RowGameModel model) {
        for(int i = 0; 3 > i; ++i) {
            for(int j = 0; 3 > j; ++j) {
                this.updateBlock(model, i, j);
            }
        }

    }

    public int[] getPosition(JButton button) {
        for(int i = 0; i < this.blocks.length; ++i) {
            for(int j = 0; j < this.blocks[i].length; ++j) {
                if (button == this.blocks[i][j]) {
                    return new int[]{i, j};
                }
            }
        }

        return null;
    }
}

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package view;

import controller.RowGameController;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import model.RowGameModel;

public class RowGameGUI implements View {
    public JFrame gui = new JFrame("Tic Tac Toe");
    public ComponentA game;
    public ComponentC status;
    public JButton reset = new JButton("Reset");
    public JButton undo = new JButton("Undo");

    public RowGameGUI(final RowGameController controller) {
        this.gui.setDefaultCloseOperation(3);
        this.gui.setSize(new Dimension(500, 350));
        this.gui.setResizable(true);
        JPanel gamePanel = new JPanel(new FlowLayout());
        JPanel gameP = new JPanel(new GridLayout(3, 3));
        gamePanel.add(gameP, "Center");
        JPanel options = new JPanel(new FlowLayout());
        options.add(this.reset);
        options.add(this.undo);
        JPanel messages = new JPanel(new FlowLayout());
        messages.setBackground(Color.white);
        this.gui.add(gamePanel, "North");
        this.gui.add(options, "Center");
        this.gui.add(messages, "South");
        this.status = new ComponentC(messages);
        this.reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.resetGame();
            }
        });
        this.undo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.undoGame();
            }
        });
        this.game = new ComponentA(controller, gameP);
    }

    public void update(RowGameModel model) {
        this.game.update(model);
        this.status.update(model);
        this.undo.setEnabled(!model.undoStack.isEmpty());
    }
}

package view;

import model.RowGameModel;

interface View {
    public void update(RowGameModel model);
}


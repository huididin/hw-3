//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package controller;

import javax.swing.JButton;
import model.RowBlockModel;
import model.RowGameModel;
import model.RowGameModel.Player;
import view.ComponentA;
import view.ComponentC;
import view.RowGameGUI;

public class RowGameController {
	public RowGameModel gameModel = new RowGameModel();
	public RowGameGUI gameView = new RowGameGUI(this);
	public ComponentA componentA;
	public ComponentC componentC;

	public RowGameController() {
		this.resetGame();
	}

	public void move(JButton block) {
		if (block.isEnabled() && this.gameModel.getFinalResult() == null) {
			--this.gameModel.movesLeft;
			if (this.gameModel.movesLeft % 2 == 1) {
				this.gameView.update(this.gameModel);
			} else {
				this.gameView.update(this.gameModel);
			}

			boolean isPlayer0 = this.gameModel.getPlayer().equals(Player.PLAYER_0);
			int[] pos = this.gameView.game.getPosition(block);
			int row = pos[0];
			int col = pos[1];
			this.gameModel.blocksData[row][col].setContents(isPlayer0 ? "X" : "O");
			this.gameView.game.updateBlock(this.gameModel, row, col);
			this.gameModel.setPlayer(isPlayer0 ? Player.PLAYER_1 : Player.PLAYER_0);
			this.gameModel.blocksData[row][col].setIsLegalMove(false);
			this.gameModel.addHistory(this.gameModel.blocksData[row][col]);
			if (isPlayer0) {
				if (block == this.gameView.game.blocks[0][0]) {
					if (this.gameModel.movesLeft < 7) {
						if (this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[0][1].getContents()) && this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[1][0].getContents()) && this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[2][0].getContents()) || this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[2][2].getContents())) {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						} else if (this.gameModel.movesLeft == 0) {
							this.gameModel.setFinalResult("Game ends in a draw");
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[0][1]) {
					if (this.gameModel.movesLeft < 7) {
						if ((!this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || !this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[0][2].getContents())) && (!this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[2][1].getContents()))) {
							if (this.gameModel.movesLeft == 0) {
								this.gameModel.setFinalResult("Game ends in a draw");
							}
						} else {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[0][2]) {
					if (this.gameModel.movesLeft < 7) {
						if ((!this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[0][1].getContents()) || !this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[0][0].getContents())) && (!this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[1][2].getContents()) || !this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[2][2].getContents())) && (!this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[2][0].getContents()))) {
							if (this.gameModel.movesLeft == 0) {
								this.gameModel.setFinalResult("Game ends in a draw");
							}
						} else {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[1][0]) {
					if (this.gameModel.movesLeft < 7) {
						if ((!this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[1][2].getContents())) && (!this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || !this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[2][0].getContents()))) {
							if (this.gameModel.movesLeft == 0) {
								this.gameModel.setFinalResult("Game ends in a draw");
							}
						} else {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[1][1]) {
					if (this.gameModel.movesLeft < 7) {
						if ((!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[1][0].getContents()) || !this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[1][2].getContents())) && (!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][1].getContents()) || !this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[2][1].getContents())) && (!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || !this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[2][2].getContents())) && (!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || !this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[2][0].getContents()))) {
							if (this.gameModel.movesLeft == 0) {
								this.gameModel.setFinalResult("Game ends in a draw");
							}
						} else {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[1][2]) {
					if (this.gameModel.movesLeft < 7) {
						if ((!this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || !this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[2][2].getContents())) && (!this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[1][0].getContents()))) {
							if (this.gameModel.movesLeft == 0) {
								this.gameModel.setFinalResult("Game ends in a draw");
							}
						} else {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[2][0]) {
					if (this.gameModel.movesLeft < 7) {
						if ((!this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[2][1].getContents()) || !this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[2][2].getContents())) && (!this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[1][0].getContents()) || !this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[0][0].getContents())) && (!this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][2].getContents()))) {
							if (this.gameModel.movesLeft == 0) {
								this.gameModel.setFinalResult("Game ends in a draw");
							}
						} else {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[2][1]) {
					if (this.gameModel.movesLeft < 7) {
						if (this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[2][0].getContents()) && this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[2][2].getContents()) || this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][1].getContents())) {
							this.gameModel.setFinalResult("Player 1 wins!");
							this.endGame();
						} else if (this.gameModel.movesLeft == 0) {
							this.gameModel.setFinalResult("Game ends in a draw");
						}

						if (this.gameModel.getFinalResult() != null) {
							this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
							this.gameView.status.playerturn.setEditable(false);
						}
					}
				} else if (block == this.gameView.game.blocks[2][2] && this.gameModel.movesLeft < 7) {
					if (this.gameModel.blocksData[2][2].getContents().equals(this.gameModel.blocksData[2][1].getContents()) && this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[2][0].getContents()) || this.gameModel.blocksData[2][2].getContents().equals(this.gameModel.blocksData[1][2].getContents()) && this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || this.gameModel.blocksData[2][2].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][0].getContents())) {
						this.gameModel.setFinalResult("Player 1 wins!");
						this.endGame();
					} else if (this.gameModel.movesLeft == 0) {
						this.gameModel.setFinalResult("Game ends in a draw");
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[0][0]) {
				if (this.gameModel.movesLeft < 7) {
					if (this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[0][1].getContents()) && this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[1][0].getContents()) && this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[2][0].getContents()) || this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[2][2].getContents())) {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					} else if (this.gameModel.movesLeft == 0) {
						this.gameModel.setFinalResult("Game ends in a draw");
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[0][1]) {
				if (this.gameModel.movesLeft < 7) {
					if ((!this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || !this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[0][2].getContents())) && (!this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[2][1].getContents()))) {
						if (this.gameModel.movesLeft == 0) {
							this.gameModel.setFinalResult("Game ends in a draw");
						}
					} else {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[0][2]) {
				if (this.gameModel.movesLeft < 7) {
					if (this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[0][1].getContents()) && this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[1][2].getContents()) && this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[2][2].getContents()) || this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[2][0].getContents())) {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					} else if (this.gameModel.movesLeft == 0) {
						this.gameModel.setFinalResult("Game ends in a draw");
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[1][0]) {
				if (this.gameModel.movesLeft < 7) {
					if ((!this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[1][2].getContents())) && (!this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || !this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[2][0].getContents()))) {
						if (this.gameModel.movesLeft == 0) {
							this.gameModel.setFinalResult("Game ends in a draw");
						}
					} else {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[1][1]) {
				if (this.gameModel.movesLeft < 7) {
					if ((!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[1][0].getContents()) || !this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[1][2].getContents())) && (!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][1].getContents()) || !this.gameModel.blocksData[0][1].getContents().equals(this.gameModel.blocksData[2][1].getContents())) && (!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || !this.gameModel.blocksData[0][0].getContents().equals(this.gameModel.blocksData[2][2].getContents())) && (!this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || !this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[2][0].getContents()))) {
						if (this.gameModel.movesLeft == 0) {
							this.gameModel.setFinalResult("Game ends in a draw");
						}
					} else {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[1][2]) {
				if (this.gameModel.movesLeft < 7) {
					if ((!this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || !this.gameModel.blocksData[0][2].getContents().equals(this.gameModel.blocksData[2][2].getContents())) && (!this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[1][1].getContents()) || !this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[1][0].getContents()))) {
						if (this.gameModel.movesLeft == 0) {
							this.gameModel.setFinalResult("Game ends in a draw");
						}
					} else {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[2][0]) {
				if (this.gameModel.movesLeft < 7) {
					if (this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[2][1].getContents()) && this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[2][2].getContents()) || this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[1][0].getContents()) && this.gameModel.blocksData[1][0].getContents().equals(this.gameModel.blocksData[0][0].getContents()) || this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][2].getContents())) {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					} else if (this.gameModel.movesLeft == 0) {
						this.gameModel.setFinalResult("Game ends in a draw");
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[2][1]) {
				if (this.gameModel.movesLeft < 7) {
					if (this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[2][0].getContents()) && this.gameModel.blocksData[2][0].getContents().equals(this.gameModel.blocksData[2][2].getContents()) || this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][1].getContents())) {
						this.gameModel.setFinalResult("Player 2 wins!");
						this.endGame();
					} else if (this.gameModel.movesLeft == 0) {
						this.gameModel.setFinalResult("Game ends in a draw");
					}

					if (this.gameModel.getFinalResult() != null) {
						this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
						this.gameView.status.playerturn.setEditable(false);
					}
				}
			} else if (block == this.gameView.game.blocks[2][2] && this.gameModel.movesLeft < 7) {
				if (this.gameModel.blocksData[2][2].getContents().equals(this.gameModel.blocksData[2][1].getContents()) && this.gameModel.blocksData[2][1].getContents().equals(this.gameModel.blocksData[2][0].getContents()) || this.gameModel.blocksData[2][2].getContents().equals(this.gameModel.blocksData[1][2].getContents()) && this.gameModel.blocksData[1][2].getContents().equals(this.gameModel.blocksData[0][2].getContents()) || this.gameModel.blocksData[2][2].getContents().equals(this.gameModel.blocksData[1][1].getContents()) && this.gameModel.blocksData[1][1].getContents().equals(this.gameModel.blocksData[0][0].getContents())) {
					this.gameModel.setFinalResult("Player 2 wins!");
					this.endGame();
				} else if (this.gameModel.movesLeft == 0) {
					this.gameModel.setFinalResult("Game ends in a draw");
				}

				if (this.gameModel.getFinalResult() != null) {
					this.gameView.status.playerturn.setText(this.gameModel.getFinalResult());
					this.gameView.status.playerturn.setEditable(false);
				}
			}

			this.gameView.update(this.gameModel);
		}
	}

	public void endGame() {
		for(int row = 0; row < 3; ++row) {
			for(int column = 0; column < 3; ++column) {
				this.gameView.game.blocks[row][column].setEnabled(false);
			}
		}

		this.gameView.update(this.gameModel);
	}

	public void resetGame() {
		for(int row = 0; row < 3; ++row) {
			for(int column = 0; column < 3; ++column) {
				this.gameModel.blocksData[row][column].reset();
				this.gameModel.blocksData[row][column].setIsLegalMove(true);
			}
		}

		this.gameModel.setPlayer(Player.PLAYER_0);
		this.gameModel.movesLeft = 9;
		this.gameModel.setFinalResult((String)null);
		this.gameView.update(this.gameModel);
	}

	public void undoGame() {
		if (this.gameModel.undoStack.isEmpty()) {
			this.gameView.status.playerturn.setText("No moves to undo");
		} else {
			boolean isPlayer0 = this.gameModel.getPlayer() == Player.PLAYER_0;
			this.gameModel.setPlayer(isPlayer0 ? Player.PLAYER_1 : Player.PLAYER_0);
			++this.gameModel.movesLeft;
			this.gameModel.setFinalResult((String)null);
			RowBlockModel blockModel = (RowBlockModel)this.gameModel.undoStack.pop();
			blockModel.reset();
			blockModel.setIsLegalMove(true);
			this.gameView.update(this.gameModel);
		}
	}
}

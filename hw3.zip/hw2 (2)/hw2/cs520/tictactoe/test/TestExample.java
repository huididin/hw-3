//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import controller.RowGameController;
import javax.swing.JButton;
import model.RowBlockModel;
import model.RowGameModel;
import model.RowGameModel.Player;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TestExample {
    private RowGameController game;

    public TestExample() {
    }

    @Before
    public void setUp() {
        this.game = new RowGameController();
    }

    @After
    public void tearDown() {
        this.game = null;
    }

    @Test(
            expected = IllegalArgumentException.class
    )
    public void testNewBlockViolatesPrecondition() {
        new RowBlockModel((RowGameModel)null);
    }

    @Test
    public void test_1_illegal_move() {
        this.game.move(this.game.gameView.game.blocks[0][0]);
        int movesLeft1 = this.game.gameModel.movesLeft;
        String contents1 = this.game.gameModel.blocksData[0][0].getContents();
        this.game.move(this.game.gameView.game.blocks[0][0]);
        int movesLeft2 = this.game.gameModel.movesLeft;
        String contents2 = this.game.gameModel.blocksData[0][0].getContents();
        Assert.assertEquals((long)movesLeft1, (long)movesLeft2);
        Assert.assertEquals(contents1, contents2);
    }

    @Test
    public void test_2_legal_move() {
        this.game.move(this.game.gameView.game.blocks[0][0]);
        int movesLeft1 = this.game.gameModel.movesLeft;
        String contents1 = this.game.gameModel.blocksData[0][0].getContents();
        this.game.move(this.game.gameView.game.blocks[0][1]);
        int movesLeft2 = this.game.gameModel.movesLeft;
        String contents2 = this.game.gameModel.blocksData[0][1].getContents();
        Assert.assertEquals((long)(movesLeft1 - 1), (long)movesLeft2);
        Assert.assertNotEquals(contents1, contents2);
    }

    @Test
    public void test_3_win() {
        JButton[][] blocks = this.game.gameView.game.blocks;
        this.game.move(blocks[0][0]);
        this.game.move(blocks[0][1]);
        this.game.move(blocks[1][0]);
        this.game.move(blocks[1][1]);
        this.game.move(blocks[2][0]);
        Assert.assertEquals("Player 1 wins!", this.game.gameModel.getFinalResult());
    }

    @Test
    public void test_4_tie() {
        JButton[][] blocks = this.game.gameView.game.blocks;
        this.game.move(blocks[0][0]);
        this.game.move(blocks[1][0]);
        this.game.move(blocks[0][1]);
        this.game.move(blocks[1][1]);
        this.game.move(blocks[1][2]);
        this.game.move(blocks[0][2]);
        this.game.move(blocks[2][0]);
        this.game.move(blocks[2][1]);
        this.game.move(blocks[2][2]);
        Assert.assertEquals("Game ends in a draw", this.game.gameModel.getFinalResult());
    }

    @Test
    public void test_5_reset() {
        JButton[][] blocks = this.game.gameView.game.blocks;
        this.game.move(blocks[0][0]);
        this.game.move(blocks[2][0]);
        this.game.resetGame();
        Assert.assertEquals(this.game.gameModel.getPlayer(), Player.PLAYER_0);
        Assert.assertEquals(9L, (long)this.game.gameModel.movesLeft);
        Assert.assertEquals((Object)null, this.game.gameModel.getFinalResult());
    }

    @Test
    public void test_6_not_permit_undo() {
        JButton[][] blocks = this.game.gameView.game.blocks;
        int gameleft1 = this.game.gameModel.movesLeft;
        Assert.assertFalse(this.game.gameView.undo.isEnabled());
        this.game.undoGame();
        Assert.assertEquals(this.game.gameModel.getPlayer(), Player.PLAYER_0);
        Assert.assertEquals((long)this.game.gameModel.movesLeft, (long)gameleft1);
    }

    @Test
    public void test_7_permit_undo() {
        JButton[][] blocks = this.game.gameView.game.blocks;
        this.game.move(blocks[0][0]);
        this.game.move(blocks[2][0]);
        int gameleft1 = this.game.gameModel.movesLeft;
        Assert.assertTrue(this.game.gameView.undo.isEnabled());
        this.game.undoGame();
        Assert.assertEquals(this.game.gameModel.getPlayer(), Player.PLAYER_1);
        Assert.assertEquals((long)this.game.gameModel.movesLeft, (long)(gameleft1 + 1));
        Assert.assertTrue(this.game.gameModel.blocksData[2][0].getIsLegalMove());
    }
}
